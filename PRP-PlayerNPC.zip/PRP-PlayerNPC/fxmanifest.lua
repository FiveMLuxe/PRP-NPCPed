fx_version 'cerulean'
game 'gta5'

author 'Elusive'
description 'PedPlacer'
version '1.0.0'

shared_script 'config.lua'
client_script 'client/cl_*.lua'
server_script 'server/sv_*.lua'
lua54 'yes'